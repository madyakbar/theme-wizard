<?php
/**
 * Content AI Page main view.
 *
 * @package RankMath
 * @subpackage RankMath\Role_Manager
 */

defined( 'ABSPATH' ) || exit;

// Header.
rank_math()->admin->display_admin_header();
?>
<div class="wrap rank-math-wrap" id="rank-math-content-ai-page">
	<div class="rank-math-box container">
	</div>
</div>
